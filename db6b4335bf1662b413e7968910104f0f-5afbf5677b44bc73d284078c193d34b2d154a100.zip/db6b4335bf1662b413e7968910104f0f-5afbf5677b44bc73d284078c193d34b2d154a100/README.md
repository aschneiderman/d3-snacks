A demonstration of [d3-zoom](https://github.com/d3/d3-zoom) driving changes to scales’ domains.

Colors from [Nadieh Bremer](http://www.visualcinnamon.com/)’s lovely [SVG gradient tutorial](http://www.visualcinnamon.com/2016/05/smooth-color-legend-d3-svg-gradient.html).
